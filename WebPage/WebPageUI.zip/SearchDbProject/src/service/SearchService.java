package service;

import com.alibaba.fastjson.JSONObject;

import dao.SearchDao;

public class SearchService {
	public JSONObject searchAll(String userid, String producttype) {
		JSONObject json = new JSONObject();
		String result = "";
		//组装sql语句
		String sql = "";
		if(producttype.equals("Movies")){
			sql = "SELECT * FROM moviereco where info like '"+userid+"%'";
		}else if(producttype.equals("Automotive")){
			sql = "SELECT * FROM automotivereco where info like '"+userid+"%'";
		}else{
			sql = "SELECT * FROM cellphoneacessreco where info like '"+userid+"%'";
		}
		System.out.println(sql);
		SearchDao sd = new SearchDao();
		result = sd.getInfo(sql);

		if(!result.equals("")){
			String[] res = result.split("::");
			result = "";
			for(int i = 1; i< res.length && i <= 5;i++){
				result += i + ". " +res[i]+"\n";
			}
		}
		json.put("result", result);
		return json;
	}
}
