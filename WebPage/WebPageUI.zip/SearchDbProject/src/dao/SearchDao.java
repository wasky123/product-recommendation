package dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import common.DB;

public class SearchDao {
	public String getInfo(String sql){
		DB db = new DB();
		db.getConnection();
		ResultSet rs = db.select(sql);
		String result = "";
		try {
			if(rs.next()){
				result = rs.getString("info");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block

			e.printStackTrace();
		}
		db.close();
		return result;
	}
}
