package common;
public class PublicInfo {	
	public static final String DRIVER = "com.mysql.jdbc.Driver";
	public static final String URL = "jdbc:mysql://127.0.0.1:3306/searchdb?useunicode=true&characterEncoding=gbk";
	public static final String USERNAME = "root";
	public static final String PASSWORD = "123";

}