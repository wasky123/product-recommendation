package common;


import java.io.IOException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletResponse;
//数据返回给前端，实际实现方式
public class Ajax extends HttpServlet{
	/**

	 * ajax

	 * @param response

	 * @param json 
	 * @throws IOException 

	 * @throws IOException

	 */
	public static void ajaxReturn(HttpServletResponse response,String json) throws IOException {
		response.setContentType("application/json;charset=utf-8");   
        response.setHeader("Cache-Control", "no-cache");  
		response.getWriter().write(json);
		response.getWriter().flush();
		response.getWriter().close();
	}

}
