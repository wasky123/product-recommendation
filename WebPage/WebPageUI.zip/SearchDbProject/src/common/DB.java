package common;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class DB {
	private Connection conn = null;
	private Statement stmt = null;
	private ResultSet rs = null;
	private PreparedStatement pst = null;

	public void getConnection(){

		try {
			Class.forName(PublicInfo.DRIVER);
			conn = DriverManager.getConnection(PublicInfo.URL, PublicInfo.USERNAME, PublicInfo.PASSWORD);
			stmt = conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block

			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block

			e.printStackTrace();
		}
		
	}

	public ResultSet select(String sql){
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block

			e.printStackTrace();
		}
		return rs;
	}

	public int update(String sql){
		try {
			int result = stmt.executeUpdate(sql);
			return result;
		} catch (SQLException e) {
			// TODO Auto-generated catch block

			e.printStackTrace();
		}
		return 0;
	}

	public int insert(String sql){
		try {
			int result = stmt.executeUpdate(sql);
			return result;
		} catch (SQLException e) {
			// TODO Auto-generated catch block

			e.printStackTrace();
		}
		return 0;
	}
	
	public void close(){
		if(stmt!=null){
			try{
				stmt.close();
				stmt = null;
			}catch(SQLException e){
				e.printStackTrace();  
                System.out.println("close stmt error");  
			}
		}
		if(pst!=null){
			try{
				pst.close();
				pst = null;
			}catch(SQLException e){
				e.printStackTrace();  
                System.out.println("close pst error");  
			}
		}
		if(rs!=null){  
            try{  
                rs.close();  
                rs=null;  
            }catch(SQLException e){  
                e.printStackTrace();  
                System.out.println("close ResultSet error");  
            }  
        }  
      
        if(conn!=null){  
            try{  
                conn.close();  
                conn=null;  
            }catch(SQLException e){  
                e.printStackTrace();  
                System.out.println("close Connection error");  
            }  
        }  
	}
}